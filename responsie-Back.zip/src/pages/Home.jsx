import React, { useState } from "react";
import {
  AirPlane,
  SearchIcon,
  CheckIcon,
  ChevronDownIcon,
  CloseCircleIcon,
  ChevronRightIcon,
  ChevronLeftIcon,
  AirPlaneIconPopularServices,
  ChevronUpIcon,
  PcIcon,
  HeadphoneIcon,
  InternetIcon,
  CartIcon,
  QuestionIcon,
} from "../components/UI/icons";
import ButtonPrimary from "../components/UI/ButtonPrimary";
import { Listbox, Transition, Disclosure } from "@headlessui/react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper/modules";
import "swiper/css";
const ticketClasses = [
  "اکونومی",
  "پرمیوم اکونومی",
  "بیزینس",
  "پرمیوم بیزینس",
  "فرست",
  "پرمیوم فرست",
];
const popularCities = ["تهران", "مشهد", "شیراز", "کیش"];
const popularCitiesFlights = [
  {
    id: "c1",
    title: "تهران",
    flights: [
      {
        id: "f1",
        from: "شیراز",
        to: "تهران",
        price: 1700000,
        image: "/images/popularServices1.jpg",
      },
      {
        id: "f2",
        from: "تهران",
        to: "کیش",
        price: 2500000,
        image: "/images/popularServices2.jpg",
      },
      {
        id: "f3",
        from: "تهران",
        to: "مشهد",
        price: 1500000,
        image: "/images/popularServices3.jpg",
      },
      {
        id: "f4",
        from: "مشهد",
        to: "تهران",
        price: 1500000,
        image: "/images/popularServices4.jpg",
      },
    ],
  },
];

const frequentQuestions = [
  {
    title: "در هر پرواز میزان بار مجاز چقدر است؟",
    text: "بلیط تمام خطوط هوایی دنیا در سایت بیلیتو موجود است، چه پروازهایی که مبدا یا مقصد آنها ایران است و چه پروازهای داخلی دورترین کشورهای دنیا. پروازهای ایرلاین‌هایی مثل لوفت‌هانزا، امارات، قطرایرویز، ترکیش‌ایر، ایرفرانس، کی‌ال‌ام، آئروفلوت، آلیتالیا، اوکراینی، ایرایژیا، پگاسوس و ده‌ها ایرلاین دیگر در بیلیتو قابل تهیه هستند. همچنین بلیط پروازهای خارجیِ شرکت‌های هواپیمایی داخلی مانند ماهان، ایران‌ایر، قشم ایر، آتا و... نیز روی سایت بیلیتو به فروش می‌رسد.",
  },
  {
    title: "نرخ بلیط هواپیما برای نوزادان و کودکان زیر 12سال چگونه است؟",
    text: "بلیط تمام خطوط هوایی دنیا در سایت بیلیتو موجود است، چه پروازهایی که مبدا یا مقصد آنها ایران است و چه پروازهای داخلی دورترین کشورهای دنیا. پروازهای ایرلاین‌هایی مثل لوفت‌هانزا، امارات، قطرایرویز، ترکیش‌ایر، ایرفرانس، کی‌ال‌ام، آئروفلوت، آلیتالیا، اوکراینی، ایرایژیا، پگاسوس و ده‌ها ایرلاین دیگر در بیلیتو قابل تهیه هستند. همچنین بلیط پروازهای خارجیِ شرکت‌های هواپیمایی داخلی مانند ماهان، ایران‌ایر، قشم ایر، آتا و... نیز روی سایت بیلیتو به فروش می‌رسد.",
  },
  {
    title: "آیا پس از خرید اینترنتی بلیط هواپیما امکان استرداد آن وجود دارد؟",
    text: "بلیط تمام خطوط هوایی دنیا در سایت بیلیتو موجود است، چه پروازهایی که مبدا یا مقصد آنها ایران است و چه پروازهای داخلی دورترین کشورهای دنیا. پروازهای ایرلاین‌هایی مثل لوفت‌هانزا، امارات، قطرایرویز، ترکیش‌ایر، ایرفرانس، کی‌ال‌ام، آئروفلوت، آلیتالیا، اوکراینی، ایرایژیا، پگاسوس و ده‌ها ایرلاین دیگر در بیلیتو قابل تهیه هستند. همچنین بلیط پروازهای خارجیِ شرکت‌های هواپیمایی داخلی مانند ماهان، ایران‌ایر، قشم ایر، آتا و... نیز روی سایت بیلیتو به فروش می‌رسد.",
  },
  {
    title:
      "آیا پس از خرید بلیط هواپیما امکان تغییر نام یا نام خانوادگی وجود دارد؟",
    text: "بلیط تمام خطوط هوایی دنیا در سایت بیلیتو موجود است، چه پروازهایی که مبدا یا مقصد آنها ایران است و چه پروازهای داخلی دورترین کشورهای دنیا. پروازهای ایرلاین‌هایی مثل لوفت‌هانزا، امارات، قطرایرویز، ترکیش‌ایر، ایرفرانس، کی‌ال‌ام، آئروفلوت، آلیتالیا، اوکراینی، ایرایژیا، پگاسوس و ده‌ها ایرلاین دیگر در بیلیتو قابل تهیه هستند. همچنین بلیط پروازهای خارجیِ شرکت‌های هواپیمایی داخلی مانند ماهان، ایران‌ایر، قشم ایر، آتا و... نیز روی سایت بیلیتو به فروش می‌رسد.",
  },
  {
    title:
      "هنگامی که از سایت خرید بلیط هواپیما رزرو بلیط را انجام می‌دهیم امکان انتخاب صندلی مورد نظرمان وجود دارد؟",
    text: "بلیط تمام خطوط هوایی دنیا در سایت بیلیتو موجود است، چه پروازهایی که مبدا یا مقصد آنها ایران است و چه پروازهای داخلی دورترین کشورهای دنیا. پروازهای ایرلاین‌هایی مثل لوفت‌هانزا، امارات، قطرایرویز، ترکیش‌ایر، ایرفرانس، کی‌ال‌ام، آئروفلوت، آلیتالیا، اوکراینی، ایرایژیا، پگاسوس و ده‌ها ایرلاین دیگر در بیلیتو قابل تهیه هستند. همچنین بلیط پروازهای خارجیِ شرکت‌های هواپیمایی داخلی مانند ماهان، ایران‌ایر، قشم ایر، آتا و... نیز روی سایت بیلیتو به فروش می‌رسد.",
  },
  {
    title:
      "بلیط پرواز چه کشورها ایرلاین‌هایی را می‌توانم‌ در سایت بیلیتو جستجو و خریداری کنم؟",
    text: "بلیط تمام خطوط هوایی دنیا در سایت بیلیتو موجود است، چه پروازهایی که مبدا یا مقصد آنها ایران است و چه پروازهای داخلی دورترین کشورهای دنیا. پروازهای ایرلاین‌هایی مثل لوفت‌هانزا، امارات، قطرایرویز، ترکیش‌ایر، ایرفرانس، کی‌ال‌ام، آئروفلوت، آلیتالیا، اوکراینی، ایرایژیا، پگاسوس و ده‌ها ایرلاین دیگر در بیلیتو قابل تهیه هستند. همچنین بلیط پروازهای خارجیِ شرکت‌های هواپیمایی داخلی مانند ماهان، ایران‌ایر، قشم ایر، آتا و... نیز روی سایت بیلیتو به فروش می‌رسد.",
  },
  {
    title: "چطور تاریخ پرواز را تغییر دهیم؟",
    text: "بلیط تمام خطوط هوایی دنیا در سایت بیلیتو موجود است، چه پروازهایی که مبدا یا مقصد آنها ایران است و چه پروازهای داخلی دورترین کشورهای دنیا. پروازهای ایرلاین‌هایی مثل لوفت‌هانزا، امارات، قطرایرویز، ترکیش‌ایر، ایرفرانس، کی‌ال‌ام، آئروفلوت، آلیتالیا، اوکراینی، ایرایژیا، پگاسوس و ده‌ها ایرلاین دیگر در بیلیتو قابل تهیه هستند. همچنین بلیط پروازهای خارجیِ شرکت‌های هواپیمایی داخلی مانند ماهان، ایران‌ایر، قشم ایر، آتا و... نیز روی سایت بیلیتو به فروش می‌رسد.",
  },
];
const Home = () => {
  const [ticketRegion, setTicketRegion] = useState("international");
  const [ticketType, setTicketType] = useState("oneWay");
  const [selectedFrom, setSelectedFrom] = useState("");
  const [selectedTo, setSelectedTo] = useState("");
  const [selectedClass, setSelectedClass] = useState("");
  const [sliderPosition, setSliderPosition] = useState(0);
  const [popularCitySelected, setPopularCitySelected] = useState("تهران");
  const [HISTORY, setHISTORY] = useState([
    "تهران به استانبول",
    "تهران به لندن",
    " استانیول  به تهران",
    "امارات به تهران",
    "امارات به تهران",
    "عراق به ایران",
    "ایران به عراق",
    "اصفهان به  تهران ",
    "تبریز به تهران",
    "تهران  به امارات",
  ]);

  const removeHistory = (history) => {
    setHISTORY(HISTORY.filter((item) => item !== history));
  };
  const handleSlideLeft = () => {
    setSliderPosition(sliderPosition - 100); // Adjust the slide amount as needed
  };

  const handleSlideRight = () => {
    setSliderPosition(sliderPosition + 100); // Adjust the slide amount as needed
  };
  return (
    <main className='flex flex-col w-full'>
      <div className=' h-[140px] xs:h-[240px] md:h-[340px] relative homeDesktopLinerGradient bg-center bg-cover bg-no-repeat  '>
        <h1 className='container flex flex-col justify-center md:justify-start pt-8 sm:pt-20 sm:gap-8 h-full font-IRANSansXBold sm:text-3xl text-white'>
          <span>راحتی و سرعت در </span>
          <span>رزرو بلیط هواپیما با بیلیتو</span>
        </h1>
        <div className=' container md:absolute rounded-lg space-y-4 sm:space-y-10 shadow-lg w-full h-auto bg-white -bottom-[60%] lg:-bottom-[40%] xl:-bottom-[50%] left-0 right-0 mx-auto p-6 '>
          <div className='flex items-center justify-center lg:justify-start gap-10 border-b border-gray5 text-sm sm:text-base md:text-lg child:flex child:items-center child:gap-2 text-gray5 child:cursor-pointer child:transition-all'>
            {/* ticket region */}
            <div
              onClick={() => setTicketRegion("international")}
              className={`${
                ticketRegion === "international"
                  ? "text-primary font-IRANSansXBold border-b-2 scale-110 border-primary pb-3"
                  : "pb-3"
              }`}
            >
              <AirPlane />
              <span>پرواز خارجی</span>
            </div>
            <div
              onClick={() => setTicketRegion("local")}
              className={`${
                ticketRegion === "local"
                  ? "text-primary font-IRANSansXBold border-b-2 scale-110 border-primary  pb-3"
                  : "pb-3"
              }`}
            >
              <AirPlane />
              <span>پرواز داخلی</span>
            </div>
          </div>
          {/* ticket type */}
          <div className='flex items-center justify-evenly sm:justify-center lg:justify-start gap-2 sm:gap-4 text-shade3 text-xs px-5 child:sm:h-10 child:h-8 child:w-24 child:border child:border-shade1 child:rounded-lg child:transition-all'>
            <button
              onClick={() => setTicketType("oneWay")}
              className={`${
                ticketType === "oneWay" && "bg-primary text-white"
              }`}
            >
              رفت
            </button>
            <button
              onClick={() => setTicketType("roundTrip")}
              className={`${
                ticketType === "roundTrip" && "bg-primary text-white"
              }`}
            >
              برگشت
            </button>
            <button
              onClick={() => setTicketType("multiPlace")}
              className={`${
                ticketType === "multiPlace" && "bg-primary text-white"
              }`}
            >
              چند مسیره
            </button>
          </div>
          <div
            className='flex items-center gap-2 w-full justify-center flex-wrap lg:flex-nowrap  child:outline-none child:border child:h-10
           child:sm:h-12 child:rounded-lg child:border-gray3 child:px-2 child:placeholder:text-gray8 child:text-sm child:sm:text-sm child:transition-all'
          >
            {/* from */}
            <Listbox value={selectedFrom} onChange={setSelectedFrom}>
              <div className='relative w-full sm:w-[180px] child:flex '>
                <Listbox.Button className='flex items-center justify-between h-full w-full'>
                  {selectedFrom ? (
                    <span>{selectedFrom}</span>
                  ) : (
                    <span>مبدا</span>
                  )}
                  <ChevronDownIcon classes='sm:hidden' />
                </Listbox.Button>
                <Transition
                  as={"div"}
                  leave='transition ease-in duration-100'
                  leaveFrom='opacity-100'
                  leaveTo='opacity-0'
                >
                  <Listbox.Options className='absolute top-10 max-max-h-40 overflow-auto left-0 flex flex-col bg-white rounded-lg border w-full z-10'>
                    <Listbox.Option
                      className={({ active }) =>
                        `relative cursor-default select-none py-2 0 pr-4 rounded-lg ${
                          active ? "bg-gray3 text-black" : "text-gray-900"
                        }`
                      }
                      value={"ایران"}
                    >
                      {({ selected }) => (
                        <>
                          <span
                            className={`block truncate ${
                              selected ? "font-medium" : "font-normal"
                            }`}
                          >
                            ایران
                          </span>
                          {selected ? (
                            <span className='absolute inset-y-0 left-0 flex items-center pl-3 text-successLight'>
                              <CheckIcon />
                            </span>
                          ) : null}
                        </>
                      )}
                    </Listbox.Option>
                    <Listbox.Option
                      className={({ active }) =>
                        `relative cursor-default select-none py-2 0 pr-4 rounded-lg ${
                          active ? "bg-gray3 text-black" : "text-gray-900"
                        }`
                      }
                      value={"لندن"}
                    >
                      {({ selected }) => (
                        <>
                          <span
                            className={`block truncate ${
                              selected ? "font-medium" : "font-normal"
                            }`}
                          >
                            لندن
                          </span>
                          {selected ? (
                            <span className='absolute  inset-y-0 left-0 flex items-center pl-3 text-successLight'>
                              <CheckIcon />
                            </span>
                          ) : null}
                        </>
                      )}
                    </Listbox.Option>
                  </Listbox.Options>
                </Transition>
              </div>
            </Listbox>
            {/* <select
              name=''
              id=''
              className='sm:arrow-removed w-full sm:w-[180px] '
              defaultValue={"from"}
            >
              <option hidden value='from'></option>
              <option value=''></option>
            </select> */}
            <span className='hidden sm:flex-all border-none'>
              <svg
                xmlns='http://www.w3.org/2000/svg'
                fill='none'
                viewBox='0 0 24 24'
                strokeWidth={1.5}
                stroke='currentColor'
                className='w-5 h-5'
              >
                <path
                  strokeLinecap='round'
                  strokeLinejoin='round'
                  d='M7.5 21 3 16.5m0 0L7.5 12M3 16.5h13.5m0-13.5L21 7.5m0 0L16.5 12M21 7.5H7.5'
                />
              </svg>
            </span>
            {/* to */}
            <Listbox value={selectedTo} onChange={setSelectedTo}>
              <div className='relative w-full sm:w-[180px] child:flex '>
                <Listbox.Button className='flex items-center justify-between h-full w-full'>
                  {selectedTo ? <span>{selectedTo}</span> : <span>مقصد</span>}
                  <ChevronDownIcon classes='sm:hidden' />
                </Listbox.Button>
                <Transition
                  as={"div"}
                  leave='transition ease-in duration-100'
                  leaveFrom='opacity-100'
                  leaveTo='opacity-0'
                >
                  <Listbox.Options className='absolute top-10 max-max-h-40 overflow-auto left-0 flex flex-col bg-white rounded-lg border w-full z-10'>
                    <Listbox.Option
                      className={({ active }) =>
                        `relative cursor-default select-none py-2 0 pr-4 rounded-lg ${
                          active ? "bg-gray3 text-black" : "text-gray-900"
                        }`
                      }
                      value={"ترکیه"}
                    >
                      {({ selected }) => (
                        <>
                          <span
                            className={`block truncate ${
                              selected ? "font-medium" : "font-normal"
                            }`}
                          >
                            ترکیه
                          </span>
                          {selected ? (
                            <span className='absolute inset-y-0 left-0 flex items-center pl-3 text-successLight'>
                              <CheckIcon />
                            </span>
                          ) : null}
                        </>
                      )}
                    </Listbox.Option>
                    <Listbox.Option
                      className={({ active }) =>
                        `relative cursor-default select-none py-2 0 pr-4 rounded-lg ${
                          active ? "bg-gray3 text-black" : "text-gray-900"
                        }`
                      }
                      value={"لندن"}
                    >
                      {({ selected }) => (
                        <>
                          <span
                            className={`block truncate ${
                              selected ? "font-medium" : "font-normal"
                            }`}
                          >
                            لندن
                          </span>
                          {selected ? (
                            <span className='absolute inset-y-0 left-0 flex items-center pl-3 text-successLight'>
                              <CheckIcon />
                            </span>
                          ) : null}
                        </>
                      )}
                    </Listbox.Option>
                  </Listbox.Options>
                </Transition>
              </div>
            </Listbox>
            {/* date */}
            <input
              className='w-full sm:w-[200px] '
              type='text'
              placeholder='تاریخ رفت'
              onFocus={(e) => (e.target.type = "date")}
            />
            {/* passengers */}
            <input
              className='w-full sm:w-[180px]'
              type='number'
              min={1}
              max={20}
              placeholder='تعداد مسافر'
            />
            {/* class */}
            <Listbox value={selectedClass} onChange={setSelectedClass}>
              <div className='relative w-full sm:w-[160px] child:flex '>
                <Listbox.Button className='flex  justify-between items-center h-full w-full'>
                  {selectedClass ? (
                    <span>{selectedClass}</span>
                  ) : (
                    <span>کلاس پرواز</span>
                  )}
                  <ChevronDownIcon classes='sm:hidden' />
                </Listbox.Button>
                <Transition
                  as={"div"}
                  leave='transition ease-in duration-100'
                  leaveFrom='opacity-100'
                  leaveTo='opacity-0'
                >
                  <Listbox.Options className='absolute top-10 max-h-40 overflow-auto left-0 flex flex-col bg-white rounded-lg border w-full z-10'>
                    {ticketClasses.map((ticketClass, index) => (
                      <Listbox.Option
                        key={index}
                        className={({ active }) =>
                          `relative cursor-default select-none py-2 0 pr-4 rounded-lg ${
                            active ? "bg-gray3 text-black" : "text-gray-900"
                          }`
                        }
                        value={ticketClass}
                      >
                        {({ selected }) => (
                          <>
                            <span
                              className={`block truncate ${
                                selected ? "font-medium" : "font-normal"
                              }`}
                            >
                              {ticketClass}
                            </span>
                            {selected ? (
                              <span className='absolute inset-y-0 left-0 flex items-center pl-3 text-successLight'>
                                <CheckIcon />
                              </span>
                            ) : null}
                          </>
                        )}
                      </Listbox.Option>
                    ))}
                  </Listbox.Options>
                </Transition>
              </div>
            </Listbox>
            {/* <select
              name=''
              id=''
              className='w-full sm:w-[160px] sm:arrow-removed'
              defaultValue={"class"}
            >
              <option hidden disabled value='class'>
                کلاس پرواز
              </option>
              <option value=''>اکونومی</option>
              <option value=''>پرمیوم اکونومی</option>
              <option value=''>بیزینس</option>
              <option value=''>پرمیوم بیزینس</option>
              <option value=''>فرست</option>
              <option value=''>پرمیوم فرست</option>
            </select> */}
            <ButtonPrimary
              classes='w-full sm:w-[160px] rounded-lg'
              text='جستجو'
              icon={<SearchIcon />}
            />
          </div>
        </div>
      </div>
      {/* history */}
      <div className='container space-y-4 mt-10 md:mt-60 lg:mt-44 xl:mt-52 py-7 md:pb-14'>
        <div className=' flex text-lg justify-between items-center'>
          <h6 className='text-gray8 flex items-center gap-2'>
            <svg
              xmlns='http://www.w3.org/2000/svg'
              fill='none'
              viewBox='0 0 24 24'
              strokeWidth={1.5}
              stroke='currentColor'
              className='w-6 h-6'
            >
              <path
                strokeLinecap='round'
                strokeLinejoin='round'
                d='m15.75 15.75-2.489-2.489m0 0a3.375 3.375 0 1 0-4.773-4.773 3.375 3.375 0 0 0 4.774 4.774ZM21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z'
              />
            </svg>
            <span> تاریخچه جستجو</span>
          </h6>
          <span className='text-primary cursor-pointer'>پاک کردن همه</span>
        </div>
        <div className='container flex items-center justify-between'>
          <span className=' border p-2 rounded-lg' onClick={handleSlideLeft}>
            <ChevronRightIcon />
          </span>
          <div className='flex overflow-hidden items-start justify-start text-sm'>
            {HISTORY.map((history, index) => (
              <div
                dir='rtl'
                key={index}
                className=' px-2  '
                style={{ transform: `translateX(${sliderPosition}px)` }}
              >
                <div className='flex items-center px-2 sm:w-[165px] text-nowrap gap-1 border rounded-lg py-2 shadow-md overflow-hidden'>
                  <span onClick={() => removeHistory(history)}>
                    <CloseCircleIcon classes='w-4 h-4 md:w-5 md:h-5' />
                  </span>
                  <span>{history}</span>
                </div>
              </div>
            ))}
          </div>
          <span className=' border p-2 rounded-lg' onClick={handleSlideRight}>
            <ChevronLeftIcon />
          </span>
        </div>
      </div>
      {/* services */}
      <div className='container flex flex-col md:flex-row items-center gap-3 lg:gap-6 pb-7 md:pb-14  '>
        <div className='services1 relative w-full h-[152px] md:h-[328px] bg-cover bg-center bg-no-repeat rounded-lg shadow-2xl'>
          <div className='absolute bottom-0 right-0 p-6 text-white flex flex-col gap-2'>
            <span className='font-IRANSansXBold sm:text-xl'>
              بهترین فصل شنا
            </span>
            <span className='font-IRANSansXMedium text-xs sm:text-sm border border-white rounded-lg p-2'>
              خرید بلیط پرواز‌های کیش
            </span>
          </div>
        </div>
        <div className='services2 relative w-full h-[152px] md:h-[328px] bg-cover bg-center bg-no-repeat rounded-lg shadow-2xl'>
          <div className='absolute bottom-0 right-0 p-6 text-white flex flex-col gap-2'>
            <span className='font-IRANSansXBold sm:text-xl'>سفر به ترکیه</span>
            <span className='font-IRANSansXMedium text-xs sm:text-sm border border-white rounded-lg p-2'>
              خرید بلیط پرواز‌های ترکیه
            </span>
          </div>
        </div>
        <div className='flex flex-col justify-between gap-3 md:gap-6 w-full'>
          <div className='services3 relative w-full md:w-[220px] lg:w-[392px] h-[152px] bg-cover bg-center bg-no-repeat rounded-lg shadow-2xl'>
            <div className='absolute bottom-0 right-0 p-6 text-white flex flex-col gap-2'>
              <span className='font-IRANSansXBold sm:text-xl'>
                دنیایی از تاریخ و هنر
              </span>
              <span className='font-IRANSansXMedium text-xs sm:text-sm border border-white rounded-lg p-2'>
                خرید بلیط پرواز‌های شیراز
              </span>
            </div>
          </div>
          <div className='services4 relative w-full md:w-[220px] lg:w-[392px] h-[152px] bg-cover bg-center bg-no-repeat rounded-lg shadow-2xl'>
            <div className='absolute bottom-0 right-0 p-6 text-white flex flex-col gap-2'>
              <span className='font-IRANSansXBold sm:text-xl'>
                شگفتی در صحرا
              </span>
              <span className='font-IRANSansXMedium text-xs sm:text-sm border border-white rounded-lg p-2'>
                خرید بلیط پرواز‌های دبی
              </span>
            </div>
          </div>
        </div>
      </div>
      {/* popular services */}
      <div className='container pb-7 md:pb-14 space-y-6'>
        <h6 className='font-IRANSansXBold sm:text-xl text-black'>
          پرطرفدار ترین پروازهای داخلی
        </h6>
        <div className='flex items-center flex-wrap  gap-2'>
          {popularCities.map((city) => (
            <span
              onClick={() => setPopularCitySelected(city)}
              className={`text-lg px-4 py-1 rounded-lg transition-colors shadow-md ${
                popularCitySelected === city
                  ? "bg-tint1 text-primary"
                  : "bg-white text-gray7"
              }`}
              key={city}
            >
              {city}
            </span>
          ))}
        </div>
        {popularCitiesFlights
          .filter((item) => item.title === popularCitySelected)
          .map((item) => (
            <Swiper
              spaceBetween={10}
              slidesPerView={"auto"}
              centeredSlides={true}
              autoplay={{
                delay: 2500,
                disableOnInteraction: false,
              }}
              modules={[Autoplay]}
              className='flex items-center justify-center  w-full gap-2 pt-4'
              key={item.id}
              breakpoints={{
                380: {
                  slidesPerView: 1,
                  spaceBetween: 10,
                },
                480: {
                  slidesPerView: 2,
                  spaceBetween: 10,
                  centeredSlides: false,
                },
                640: {
                  slidesPerView: 3,
                  spaceBetween: 70,
                  centeredSlides: false,
                },
                1024: {
                  slidesPerView: 4,
                  spaceBetween: 10,
                  centeredSlides: false,
                },
              }}
            >
              {item.flights.map((flight) => (
                <SwiperSlide
                  className='flex items-center w-full shadow-md '
                  key={flight.id}
                >
                  <img
                    src={flight.image}
                    alt={flight.from}
                    className='h-full w-[68px] sm:w-auto object-contain'
                  />

                  <div className='flex items-center justify-between h-[74px] sm:h-[88px] flex-col border border-gray2 rounded-md divide-y divide-gray2 child:px-4 w-full xs:w-fit  child:bg-white'>
                    {/* city Names */}
                    <div className='flex-all gap-2 items-center w-full h-full '>
                      <span
                        className={`text-xs md:text-base ${
                          popularCitySelected === flight.from && "text-primary"
                        }`}
                      >
                        {flight.from}
                      </span>
                      <AirPlaneIconPopularServices />
                      <span
                        className={`text-xs md:text-base ${
                          popularCitySelected === flight.to && "text-primary"
                        }`}
                      >
                        {flight.to}
                      </span>
                    </div>
                    {/* price */}
                    <div className='flex-all w-full h-full flex-row items-center gap-2'>
                      <span className='text-xs text-gray6'>شروع قیمت از:</span>
                      <span className='text-gray9 text-sm sm:textbase'>
                        {flight.price.toLocaleString("fa-IR")}
                        <span className='text-[10px] mr-1'>تومان</span>
                      </span>
                    </div>
                  </div>
                </SwiperSlide>
              ))}
            </Swiper>
          ))}
        {popularCitiesFlights.findIndex(
          (item) => item.title === popularCitySelected
        ) === -1 && (
          <span className='block text-xl text-center py-4 text-gray6'>
            موردی برای نمایش وجود ندارد.
          </span>
        )}
      </div>
      {/* fequent questions */}
      <div className='container py-7 text-gray8 space-y-6'>
        <h6 className='font-IRANSansXBold text-xl '>سوالات متداول</h6>
        <div className='border border-gray2 rounded-lg shadow-sm divide-y divide-gray2 '>
          {frequentQuestions.map((question) => (
            <Disclosure>
              {({ open }) => (
                <>
                  <Disclosure.Button className='flex w-full justify-between gap-2 px-4 py-3 md:py-4 text-right hover:bg-gray2 transition-all focus:outline-none focus-visible:ring child:transition-all focus-visible:ring-purple-500/75'>
                    <span
                      className={`flex items-center gap-2 ${
                        open
                          ? "text-primary text-xs md:text-sm lg:text-base font-IRANSansXBold"
                          : "text-xs  md:text-sm lg:text-lg font-IRANSansXMedium"
                      } `}
                    >
                      <span className='flex-all w-5 h-5 bg-tint2 rounded-full text-primary'>
                        <QuestionIcon />
                      </span>

                      {question.title}
                    </span>
                    <ChevronUpIcon
                      classes={`w-4 h-4 md:w-5 md:h-5 ${
                        open ? " rotate-180 transform text-primary" : ""
                      } `}
                    />
                  </Disclosure.Button>
                  <Transition
                    enter='transition duration-100 ease-out'
                    enterFrom='transform -translate-y-2 opacity-0'
                    enterTo='transform translate-y-0 opacity-100'
                    leave='transition duration-75 ease-out'
                    leaveFrom='transform translate-y-0 opacity-100'
                    leaveTo='transform -translate-y-2 opacity-0'
                  >
                    <Disclosure.Panel className='px-4 pb-2 pt-4 text-[10px] md:text-lg text-gray6 text-justify'>
                      {question.text}
                    </Disclosure.Panel>
                  </Transition>
                </>
              )}
            </Disclosure>
          ))}
        </div>
      </div>
      {/* benfifts */}
      <div className='container flex items-center justify-evenly gap-2 text-shade4 text-xs xs:text-sm md:text-xl text-center md:font-IRANSansXBold mt-14 bg-tint1 py-7 rounded-lg shadow-md'>
        <div className='flex-all flex-col gap-3 md:gap-6 '>
          <span className='p-1.5 md:p-3.5 rounded-xl md:rounded-3xl border border-primary '>
            <PcIcon />
          </span>
          <span>دسترسی آسان و راحت</span>
        </div>
        <div className='flex-all flex-col gap-3 md:gap-6'>
          <span className='p-1.5 md:p-3.5 rounded-xl md:rounded-3xl border border-primary '>
            <HeadphoneIcon />
          </span>
          <span>پاسخگویی 24 ساعته</span>
        </div>
        <div className='flex-all flex-col gap-3 md:gap-6'>
          <span className='p-1.5 md:p-3.5 rounded-xl md:rounded-3xl border border-primary '>
            <InternetIcon />
          </span>
          <span>خدمات آنلاین</span>
        </div>
        <div className='flex-all flex-col gap-3 md:gap-6'>
          <span className='p-1.5 md:p-3.5 rounded-xl md:rounded-3xl border border-primary '>
            <CartIcon />
          </span>
          <span>کمترین نرخ خرید بلیط</span>
        </div>
      </div>
    </main>
  );
};

export default Home;
