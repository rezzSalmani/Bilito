import React from "react";

const Footer = () => {
  return (
    <footer className='bg-red-400 pt-1'>
      <div className=''>
        <img
          src='/images/mainLogo.svg'
          alt='Logo'
          className='w-[100px] xl:w-[148px]'
        />
      </div>
      <span>تلفن پشتیبانی: 98 76 54 32_021</span>
      <span>
        آدرس دفتر مرکزی: تهران، میدان آزادی، خیابان آزادی، خیابان جیحون، طوس
        غربی.
      </span>
    </footer>
  );
};

export default Footer;
