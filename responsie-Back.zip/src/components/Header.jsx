import React, { useState } from "react";
import { NavLink, Link } from "react-router-dom";
import ButtonPrimary from "./UI/ButtonPrimary";
import {
  AirPlane,
  BarIcon,
  CloseCircleIcon,
  PhoneIcon,
  UserIcon,
} from "./UI/icons";
const Header = () => {
  const [openMobileMenu, setMobileOpenMenu] = useState(false);
  return (
    <section className=' relative'>
      {/* desktop menu */}
      <div className=' container hidden md:flex items-center justify-between bg-white h-[104px] '>
        <div className='flex items-center gap-8 xl:gap-14'>
          <img
            src='/images/mainLogo.svg'
            alt='Logo'
            className='w-[100px] xl:w-[148px]'
          />
          <ul className='flex items-center gap-4 xl:gap-8 child:py-2 w-full font-IRANSansXDemiBold xl:text-xl text-right child:min-h-full'>
            <li>
              <NavLink
                to='/'
                className={({ isActive }) =>
                  isActive ? "text-primary border-b border-primary" : ""
                }
              >
                صفحه اصلی
              </NavLink>
            </li>
            <li>
              <NavLink
                to='/travel-insurance'
                className={({ isActive }) =>
                  isActive ? "text-primary border-b border-primary" : ""
                }
              >
                بیمه مسافرتی
              </NavLink>
            </li>
            <li>
              <NavLink
                to='/my-travels'
                className={({ isActive }) =>
                  isActive ? "text-primary border-b border-primary" : ""
                }
              >
                سفرهای من
              </NavLink>
            </li>
            <li className='relative group'>
              <NavLink
                to='/others'
                className={({ isActive }) =>
                  isActive ? "text-primary border-b border-primary" : ""
                }
              >
                سایر موارد
                <svg
                  xmlns='http://www.w3.org/2000/svg'
                  fill='none'
                  viewBox='0 0 24 24'
                  strokeWidth={1.5}
                  stroke='currentColor'
                  className=' w-5 h-5 inline mr-1 group-hover:rotate-180 transition-all'
                >
                  <path
                    strokeLinecap='round'
                    strokeLinejoin='round'
                    d='m19.5 8.25-7.5 7.5-7.5-7.5'
                  />
                </svg>
              </NavLink>
              <div className='absolute top-10 hidden group-hover:flex bg-tint1 flex-col rounded-lg w-44 transition-all duration-200 z-10'>
                <ul className='relative child:pr-8 py-4 whitespace-nowrap shadow-sm text-base child:custom-afterElem-desktop-submenu child:flex child:items-center child-hover:pr-10 child:transition-all child:duration-200'>
                  <li>
                    <Link to='/'>سوالات متداول</Link>
                  </li>
                  <li>
                    <Link to='/'>پشتیبانی</Link>
                  </li>
                  <li>
                    <Link to='/'>درباره ما</Link>
                  </li>
                  <li>
                    <Link to='/'>تماس با ما</Link>
                  </li>
                </ul>
              </div>
            </li>
          </ul>
        </div>
        <div className='flex items-center gap-6  '>
          <div className='hidden xl:flex items-center gap-2 xl:text-xl '>
            <span>4045_021 پشتیبانی</span>
            <PhoneIcon />
          </div>
          <ButtonPrimary
            classes='py-2 px-4 rounded-lg'
            text='ورود / ثبت نام'
            icon={<UserIcon></UserIcon>}
          />
        </div>
      </div>
      {/* mobile menu */}
      <div className=' container relative flex items-center justify-between bg-white py-4 px-5 md:hidden child:cursor-pointer'>
        <span onClick={() => setMobileOpenMenu((perv) => !perv)}>
          {openMobileMenu ? <CloseCircleIcon /> : <BarIcon />}
        </span>
        <img src='/images/mainLogo.svg' alt='Logo' className='w-[100px] ' />
        <span className='p-2 bg-tint1 rounded-md'>
          <UserIcon></UserIcon>
        </span>
      </div>
      <div
        className={`md:hidden absolute w-full inset-0 bg-white z-10 transition-all duration-200 ${
          openMobileMenu
            ? "h-[calc(100vh-65px)]  visible opacity-100 translate-y-16"
            : "invisible opacity-0 h-0"
        }`}
      >
        <ul className='container flex-all flex-col child:w-fit  child:child:inline-flex child:child:justify-start child:child:gap-2 child:p-2 space-y-3 pt-10 child-hover:text-tint5 transition-all child:transition-all'>
          <li>
            <NavLink
              to='/'
              className={({ isActive }) => (isActive ? "text-primary " : "")}
            >
              <svg
                xmlns='http://www.w3.org/2000/svg'
                fill='none'
                viewBox='0 0 24 24'
                strokeWidth={1.5}
                stroke='currentColor'
                className='w-5 h-5'
              >
                <path
                  strokeLinecap='round'
                  strokeLinejoin='round'
                  d='m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25'
                />
              </svg>
              صفحه اصلی
            </NavLink>
          </li>
          <li>
            <NavLink
              to='/insurance'
              className={({ isActive }) => (isActive ? "text-primary " : "")}
            >
              <svg
                xmlns='http://www.w3.org/2000/svg'
                fill='none'
                viewBox='0 0 24 24'
                strokeWidth={1.5}
                stroke='currentColor'
                className='w-5 h-5'
              >
                <path
                  strokeLinecap='round'
                  strokeLinejoin='round'
                  d='m9 14.25 6-6m4.5-3.493V21.75l-3.75-1.5-3.75 1.5-3.75-1.5-3.75 1.5V4.757c0-1.108.806-2.057 1.907-2.185a48.507 48.507 0 0 1 11.186 0c1.1.128 1.907 1.077 1.907 2.185ZM9.75 9h.008v.008H9.75V9Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm4.125 4.5h.008v.008h-.008V13.5Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z'
                />
              </svg>
              بیمه مسافرتی
            </NavLink>
          </li>
          <li>
            <NavLink
              to='/my-trips'
              className={({ isActive }) => (isActive ? "text-primary " : "")}
            >
              <AirPlane></AirPlane>
              سفرهای من
            </NavLink>
          </li>
          <li>
            <NavLink
              to='/contact-us'
              className={({ isActive }) => (isActive ? "text-primary " : "")}
            >
              <PhoneIcon />
              تماس با ما
            </NavLink>
          </li>
          <li>
            <NavLink
              to='/about-us'
              className={({ isActive }) => (isActive ? "text-primary " : "")}
            >
              <svg
                xmlns='http://www.w3.org/2000/svg'
                fill='none'
                viewBox='0 0 24 24'
                strokeWidth={1.5}
                stroke='currentColor'
                className='w-5 h-5'
              >
                <path
                  strokeLinecap='round'
                  strokeLinejoin='round'
                  d='M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m5.231 13.481L15 17.25m-4.5-15H5.625c-.621 0-1.125.504-1.125 1.125v16.5c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Zm3.75 11.625a2.625 2.625 0 1 1-5.25 0 2.625 2.625 0 0 1 5.25 0Z'
                />
              </svg>
              درباره ما
            </NavLink>
          </li>
          <li>
            <NavLink
              to='/login'
              className={({ isActive }) => (isActive ? "text-primary " : "")}
            >
              <UserIcon />
              حساب کاربری
            </NavLink>
          </li>
          <li>
            <NavLink
              to='/support'
              className={({ isActive }) => (isActive ? "text-primary " : "")}
            >
              <svg
                xmlns='http://www.w3.org/2000/svg'
                fill='none'
                viewBox='0 0 24 24'
                strokeWidth={1.5}
                stroke='currentColor'
                className='w-5 h-5'
              >
                <path
                  strokeLinecap='round'
                  strokeLinejoin='round'
                  d='M18 18.72a9.094 9.094 0 0 0 3.741-.479 3 3 0 0 0-4.682-2.72m.94 3.198.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0 1 12 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 0 1 6 18.719m12 0a5.971 5.971 0 0 0-.941-3.197m0 0A5.995 5.995 0 0 0 12 12.75a5.995 5.995 0 0 0-5.058 2.772m0 0a3 3 0 0 0-4.681 2.72 8.986 8.986 0 0 0 3.74.477m.94-3.197a5.971 5.971 0 0 0-.94 3.197M15 6.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm6 3a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Zm-13.5 0a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Z'
                />
              </svg>
              <span>4045_021 پشتیبانی</span>
            </NavLink>
          </li>
        </ul>
      </div>
    </section>
  );
};

export default Header;
